"""
Embedded Python Blocks:

Each time this file is saved, GRC will instantiate the first class it finds
to get ports and parameters of your block. The arguments to __init__  will
be the parameters. All of them are required to have default values!
"""
import time
import numpy as np
from gnuradio import gr


class blk(gr.sync_block):  # other base classes are basic_block, decim_block, interp_block
    """Embedded Python Block example - a simple multiply const"""

    def __init__(self, slot_time=1.0):  # only default arguments here
        """arguments to this function show up as parameters in GRC"""
        gr.sync_block.__init__(
            self,
            name='Pilot generator tap',   # will show up in GRC
            in_sig=[np.complex64],
            out_sig=[np.complex64]
        )
        # if an attribute with the same name as a parameter is found,
        # a callback is registered (properties work, too).
        self.saved_time = time.time()
        self.current_time = time.time()
	self.ACK_strated = time.time()
	self.ACK_ended = time.time()
        self.slot_time = slot_time
	self.transmit_pilot_flag = False


    def work(self, input_items, output_items):
        """example: multiply with constant"""

        if self.current_time > self.saved_time + 0.4:
		self.transmit_pilot_flag = True
		self.current_time = time.time()
		if self.current_time > self.saved_time + 0.8:
			self.transmit_pilot_flag = False
			self.saved_time = time.time()
        	#if self.ACK_strated < self.saved_time + 1.1:
		#	self.saved_time = time.time()
		#	if self.ACK_ended >self.ACK_strated + 1.2:

        	#	print('ACK')
		
	else:
        	self.current_time = time.time()
        	
        if self.transmit_pilot_flag:
        	output_items[0][:] = input_items[0] #pilot goes out
	else:
		output_items[0][:] = input_items[0]*0

        #output_items[0][:] = input_items[0] 
        return len(output_items[0])
