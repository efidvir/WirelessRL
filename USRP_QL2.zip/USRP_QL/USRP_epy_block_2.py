"""
Embedded Python Blocks:

Each time this file is saved, GRC will instantiate the first class it finds
to get ports and parameters of your block. The arguments to __init__  will
be the parameters. All of them are required to have default values!
"""
import os, sys, time
import numpy as np
from gnuradio import gr


class blk(gr.sync_block):  # other base classes are basic_block, decim_block, interp_block
    """Embedded Python Block example - a simple multiply const"""

    def __init__(self, learning_rate=0.01, gamma = 0.9):  # only default arguments here
        """arguments to this function show up as parameters in GRC"""
        gr.sync_block.__init__(
            self,
            name='QL agent',   # will show up in GRC
            in_sig=[np.uint8 , np.complex64, np.uint8],
            out_sig=[np.uint8]
        )
        # if an attribute with the same name as a parameter is found,
        # a callback is registered (properties work, too).
        self.number_of_iterations = 2000
        self.iteration = 0 
        np.random.seed(0)
        #model
        MAX_SILENT_TIME = 5
        SILENT_THRESHOLD = 1
        BATTERY_SIZE = 5
        DISCHARGE = 1
        MINIMAL_CHARGE = 1
        self.minimal_charge = MINIMAL_CHARGE
        CHARGE = 1
        number_of_actions = 2
        DATA_SIZE = 10
        self.epsilon = 1
        RAND = np.random.randint(10000)
        self.learning_rate = learning_rate
        self.gamma = gamma
        self.agent = self.QLagent(self.learning_rate, self.gamma, BATTERY_SIZE, MAX_SILENT_TIME, DATA_SIZE, number_of_actions, MINIMAL_CHARGE,RAND)
        self.env = self.QLenv(BATTERY_SIZE, MAX_SILENT_TIME, SILENT_THRESHOLD, MINIMAL_CHARGE, DISCHARGE, CHARGE, DATA_SIZE, number_of_actions)
        self.action = 0
        self.prv_action = 0
        self.once = True
        self.ACK_once = True
        self.ACK_once2 = True
        self.env.state = self.env.initial_state
        self.ack = 0
        self.reward = 0 
        self.decay_rate = 0.995

        

    def work(self, input_items, output_items):
        #Check for ACK - FIX TIMEING
        if np.sum(np.square(abs(input_items[2]))) > 0.5:
        	if self.ACK_once == True:
        		self.ack = 1 
        		self.ACK_once = False
        		self.ACK_once2 = True
        else:
        	self.ACK_once = True
        	if self.ACK_once2 == True:
        		self.ack = 0
        		self.ACK_once2 = False

        """Check for Pilot"""        
        if np.sum(np.square(abs(input_items[0]))) > 0.5:
        	#time step by pilot signal
        	if self.once == True:
        		self.env.state = self.env.new_state #advance to next state
        		if self.iteration < self.number_of_iterations:
        			#Q-Learn 
        			
        			self.env.new_state, self.reward = self.env.time_step(self.action,self.ack)
        			self.action = self.agent.step(self.env.state, self.reward, self.prv_action, self.env.new_state, self.epsilon)[0] #Qlearn and tak new action
        			print('state:   ', self.env.state, 'action:   ' , self.prv_action, 'new state:   ' , self.env.new_state, 'reward' , self.reward, 'ack:   ' , self.ack)
        			self.epsilon = self.epsilon * self.decay_rate
        			self.prv_action = self.action
        		else:
        			#use policy
        			self.env.new_state, self.reward = self.env.time_step(self.action,self.ack)
        			self.action = self.agent.choose_action(self.env.new_state, 0)[0]
        			self.prv_action = self.action
        		self.iteration += 1	
        		print('iteration:     ', self.iteration)
        		self.once = False

        else:
        	self.once = True
		        	
        if self.action == 1:
        	output_items[0][:] = 1
        else:
        	output_items[0][:] = 0
        return len(output_items[0])
     
    class QLagent():
        def __init__(self, alpha, gamma, battery_size, max_silence_time, data_size, number_of_actions,MINIMAL_CHARGE,RAND):
        	self.alpha = alpha
        	self.beta = alpha
        	self.gamma = gamma
        	self.data_size = data_size
        	self.number_of_actions = number_of_actions
        	self.Q = np.zeros(shape=(battery_size, max_silence_time, self.number_of_actions))
        	self.MINIMAL_CHARGE = MINIMAL_CHARGE
        	self.seeder = RAND
        	
        def choose_action(self, state, epsilon):
        	# decompose state
        	current_energy, slient_time = state
        	# Explore ?
        	if (np.random.default_rng().uniform(size=1)[0] < epsilon):
        		np.random.seed(int(time.time_ns()%1000000))
        		action = np.random.default_rng().choice([0,1],1,p=[0.5,0.5])
        	# Exploite - Choose the current best action
        	else:
        		action = [np.argmax(self.Q[current_energy, slient_time])]  
        	# Dont have energy for transmision#################################################
        	if current_energy < self.MINIMAL_CHARGE:
        		action = [0]

        	return action
        	
        	
        def Q_learn(self, state, reward, action, new_state):
        	# decompose state
        	current_energy, slient_time = state
        	delta = reward - self.Q[current_energy, slient_time, action]

        	# decompose new state
        	next_energy, next_silence = new_state

        	delta = reward + self.gamma * (np.max(self.Q[next_energy, next_silence, :])) - self.Q[current_energy, slient_time, action]
        	if delta >=0:
        		self.Q[current_energy, slient_time, action] = self.Q[current_energy, slient_time, action] + self.alpha * delta
        	else:
        		self.Q[current_energy, slient_time, action] = self.Q[current_energy, slient_time, action] + self.beta * delta

        	return
        	
        def step(self, state, reward, action, new_state, epsilon):
        	self.Q_learn(state, reward, action, new_state)
        	new_action  = self.choose_action(new_state, epsilon)
        	return new_action 
        	
    class QLenv():
        def __init__(self, battery_size, max_silence_time, time_threshold, minimal_charge, discharge_rate, charge_rate, data_size,action_space_size):

        	# set env parameters
        	self.battery_size = battery_size
        	self.max_silence_time = max_silence_time
        	self.time_threshold = time_threshold
        	self.minimal_charge = minimal_charge
        	self.discharge_rate =  discharge_rate
        	self.charge_rate = charge_rate
        	self.data_size = data_size
        	self.action_space_size = action_space_size

        	self.initial_energy = self.battery_size
        	self.initial_silence = 0
        	self.initial_state = [self.initial_energy - 1, self.initial_silence]
        	self.state = self.initial_state
        	self.new_state = self.initial_state

        def time_step(self, action, ack):
        	# take action accoring to policy (epsilon-greedy) and get reward and next state
        #######################################################
        	current_energy, silent_time = self.state
        	reward = 0

        	if ack:
        		reward += 1
        	if action == 1:  # agent choose to transmit and discharge
        		if current_energy < self.minimal_charge:
        			raise ValueError('No charge left, can not transmit')
        		else:
        			current_energy -= self.discharge_rate

        		if ack == 0:  # Someone else transmited along with agent - collision
        			silent_time += 1
        			
        		else:  # Agent made a sucsessful report!
        			# Gateway responded!
        			silent_time = 0

        	else:  # agent choose to wait and charge
        		if current_energy < self.battery_size - 1:  # capp battery
        			current_energy += self.charge_rate

        		if ack:  # someone made a sucsessful report!
        			silent_time = 0
        		else:
        			silent_time += 1

        	if silent_time > self.max_silence_time - 1:  # capp time
        		silent_time = self.max_silence_time - 1

        	# compose new state
        	new_state = [current_energy, silent_time]

        	return new_state, reward
